<?

// The following lines will be proceed automatically at the begining....

@mysql_connect("localhost" , "root" , "") 
or die("Can not access to the database...") ;

@mysql_select_db("ehda_data") ; 
mysql_query("SET NAMES 'utf8' ");




?>