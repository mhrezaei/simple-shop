<? 
	header("location: http://www.seapurse.ir");
	die() ; 
?>